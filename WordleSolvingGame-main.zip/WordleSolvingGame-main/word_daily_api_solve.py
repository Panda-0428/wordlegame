import httpx
import enum
import collections
import random
from termcolor import colored

class Tip(enum.Enum):
    ABSENT = 0
    PRESENT = 1
    CORRECT = 2

class WordleGame:
    def __init__(self, word_length=5):
        self.WORD_LENGTH = word_length
        self.ALLOWABLE_CHARACTERS = set("abcdefghijklmnopqrstuvwxyz")
        self.WORDS = set()

    def download_word_list(self, url):
        response = httpx.get(url)
        if response.status_code == 200:
            self.WORDS = {
                word.lower()
                for word in response.text.splitlines()
                if len(word) == self.WORD_LENGTH and set(word) <= self.ALLOWABLE_CHARACTERS
            }
        else:
            print(f"Failed to download the word list from {url}.")
            self.WORDS = set()

    async def fetch_random_word(self, guess, seed=None):
        url = "https://wordle.votee.dev:8000/random"
        params = {
            "guess": guess,
            "size": self.WORD_LENGTH,
        }
        if seed is not None:
            params["seed"] = seed

        async with httpx.AsyncClient() as client:
            response = await client.get(url, params=params)

            if response.status_code == 200:
                data = response.json()
                tip_feedback = [Tip.CORRECT if item['result'].upper() == 'CORRECT' else
                                Tip.PRESENT if item['result'].upper() == 'PRESENT' else
                                Tip.ABSENT for item in data]

                print("Result:", tip_feedback)
                return tip_feedback
            else:
                print(f"Failed to fetch data. Status code: {response.status_code}")
                return None

    def display_feedback(self, guess, tip_feedback):
        for i, (tip, char) in enumerate(zip(tip_feedback, guess)):
            if tip == Tip.CORRECT:
                print(colored(char, 'green'), end="")
            elif tip == Tip.PRESENT:
                print(colored(char, 'yellow'), end="")
            else:
                print(colored(char, 'grey'), end="")
        print()

    async def play_game(self):
        self.download_word_list("https://raw.githubusercontent.com/dwyl/english-words/master/words_alpha.txt")

        words = list(self.WORDS)
        seed = random.randint(0, 10000)  # Random seed for requests

        while True:  # Infinite loop until the correct word is guessed
            print(f"I'll guess randomly from my pool of {len(words)} words...")

            # Ensure we have a reasonable list of words to guess from
            if not words:
                print("No valid words to guess from. Exiting...")
                break

            guess = random.choice(words)
            print(f"Hmmm, I'll guess {guess!r}...")

            sc = await self.fetch_random_word(guess, seed)
            if sc is None:  # If there's an error in fetching
                continue
            self.display_feedback(guess, sc)

            if all(tip == Tip.CORRECT for tip in sc):
                print(f"Congratulations! I guessed the word {guess!r}.")
                break

            words = self.filter_words(words, guess, sc)

    def filter_words(self, words, guess, score):
        new_words = []
        present_letters = collections.defaultdict(int)

        for char, tip in zip(guess, score):
            if tip == Tip.PRESENT:
                present_letters[char] += 1

        for word in words:
            # Check for correct positions and letter counts
            if all((sc == Tip.CORRECT and word[i] == guess[i]) or
                   (sc == Tip.PRESENT and word.count(guess[i]) >= count)
                   for i, (sc, count) in enumerate(zip(score, present_letters.values()))):
                new_words.append(word)

            # Exclude words that contain absent letters
            if all(char not in word for char in guess if score[guess.index(char)] == Tip.ABSENT):
                new_words.append(word)

        return new_words

if __name__ == "__main__":
    import asyncio
    game = WordleGame()
    asyncio.run(game.play_game())
