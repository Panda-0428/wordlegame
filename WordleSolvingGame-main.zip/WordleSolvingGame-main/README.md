# Wordle Solving Game

Welcome to the Wordle Solving Game, where algorithms help the computer find hidden words.

## Project Files

### 1. word_daily_api_solve.py
   - Uses the random word API to retrieve data.
   - Implements the game logic for random words.

## Running the Game

Python version 3.13

1. Install dependencies:
   ```bash
   pip install -r requirements.txt

3. Run the game:
   python word_daily_api_solve.py
